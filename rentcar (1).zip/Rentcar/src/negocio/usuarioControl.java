package Negocio;

import Data.usuarioDAO;
import Entidades.usuario;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class usuarioControl {
    private final usuarioDAO DATOS;
    private DefaultTableModel modeloTabla;
    public int registrosMostrados;

    public usuarioControl(){
        this.DATOS = new usuarioDAO();
        this.registrosMostrados = 0;
    }

    public DefaultTableModel listar(String texto){
        List<usuario> lista = new ArrayList<>();
        lista.addAll(DATOS.listar(texto));

        String[] titulos = {"Id", "Nombre", "Email", "Rol", "Activo"};
        this.modeloTabla = new DefaultTableModel(null, titulos);

        String estado;
        String[] registro = new String[5];
        this.registrosMostrados = 0;

        for (usuario item : lista){
            estado = item.isActivo() ? "Activo" : "Inactivo";

            registro[0] = String.valueOf(item.getId_usuario());
            registro[1] = item.getNombre();
            registro[2] = item.getEmail();
            registro[3] = item.getRol();
            registro[4] = estado;

            this.modeloTabla.addRow(registro);
            this.registrosMostrados++;
        }

        return this.modeloTabla;
    }

    public String insertar(String nombre, String email, String contra, String rol){
        if (DATOS.existe(nombre)){
            return "El registro ya existe.";
        } else {
            usuario obj = new usuario();
            obj.setNombre(nombre);
            obj.setEmail(email);
            obj.setContra(contra);
            obj.setRol(rol);
            obj.setActivo(true);

            if (DATOS.insertar(obj)){
                return "OK";
            } else {
                return "Error en el registro.";
            }
        }
    }

    public String actualizar(String nombre, String nombreAnt, String email, String contra, String rol){
        usuario obj = new usuario();
        obj.setNombre(nombre);
        obj.setEmail(email);
        obj.setContra(contra);
        obj.setRol(rol);

        if (nombre.equals(nombreAnt)){
            if (DATOS.actualizar(obj)){
                return "OK";
            } else {
                return "Error en la actualización.";
            }
        } else {
            if (DATOS.existe(nombre)){
                return "El registro ya existe.";
            } else {
                if (DATOS.actualizar(obj)){
                    return "OK";
                } else {
                    return "Error en la actualización.";
                }
            }
        }
    }

    public String desactivar(int id){
        if (DATOS.desactivar(id)){
            return "OK";
        } else {
            return "No se puede desactivar el registro.";
        }
    }

    public String activar(int id){
        if (DATOS.activar(id)){
            return "OK";
        } else {
            return "No se puede activar el registro.";
        }
    }

    public int total(){
        return DATOS.total();
    }

    public int totalMostrados(){
        return this.registrosMostrados;
    }
}
