package Data;

import Crud.crud;
import Entidades.usuario;
import database.conexion;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.sql.ResultSet;

public class usuarioDAO implements crud<usuario> {
    private final conexion CON;
    private PreparedStatement ps;
    private ResultSet rs;
    private boolean resp;

    public usuarioDAO(){
        CON = conexion.getInstancia();
    }

    @Override
    public List<usuario> listar(String texto) {
        List<usuario> registros = new ArrayList<>();
        try {
            ps = CON.conectar().prepareStatement("SELECT * FROM usuario WHERE nombre LIKE ?");
            ps.setString(1, "%" + texto + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                registros.add(new usuario(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("email"),
                    rs.getString("contra"),
                    rs.getString("rol"),
                    rs.getBoolean("activo")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            cerrarConexion();
        }
        return registros;
    }

    @Override
    public boolean insertar(usuario obj) {
        resp = false;
        try {
            ps = CON.conectar().prepareStatement(
                "INSERT INTO usuario (nombre, email, contra, rol, activo) VALUES (?, ?, ?, ?, ?)"
            );
            ps.setString(1, obj.getNombre());
            ps.setString(2, obj.getEmail());
            ps.setString(3, obj.getContra());
            ps.setString(4, obj.getRol());
            ps.setBoolean(5, obj.isActivo());
            if (ps.executeUpdate() > 0) {
                resp = true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            cerrarConexion();
        }
        return resp;
    }

    @Override
    public boolean actualizar(usuario obj) {
        resp = false;
        try {
            ps = CON.conectar().prepareStatement(
                "UPDATE usuario SET nombre = ?, email = ?, contra = ?, rol = ? WHERE id = ?"
            );
            ps.setString(1, obj.getNombre());
            ps.setString(2, obj.getEmail());
            ps.setString(3, obj.getContra());
            ps.setString(4, obj.getRol());
            ps.setInt(5, obj.getId_usuario());
            if (ps.executeUpdate() > 0) {
                resp = true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            cerrarConexion();
        }
        return resp;
    }

    @Override
    public boolean desactivar(int id) {
        return cambiarEstado(id, false);
    }

    @Override
    public boolean activar(int id) {
        return cambiarEstado(id, true);
    }

    private boolean cambiarEstado(int id, boolean activo) {
        resp = false;
        try {
            ps = CON.conectar().prepareStatement("UPDATE usuario SET activo = ? WHERE id = ?");
            ps.setBoolean(1, activo);
            ps.setInt(2, id);
            if (ps.executeUpdate() > 0) {
                resp = true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            cerrarConexion();
        }
        return resp;
    }

    @Override
    public int total() {
        int totalRegistros = 0;
        try {
            ps = CON.conectar().prepareStatement("SELECT COUNT(id) as total FROM usuario");
            rs = ps.executeQuery();
            if (rs.next()) {
                totalRegistros = rs.getInt("total");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            cerrarConexion();
        }
        return totalRegistros;
    }

    @Override
    public boolean existe(String texto) {
        resp = false;
        try {
            ps = CON.conectar().prepareStatement("SELECT 1 FROM usuario WHERE nombre = ?");
            ps.setString(1, texto);
            rs = ps.executeQuery();
            if (rs.next()) {
                resp = true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            cerrarConexion();
        }
        return resp;
    }

    private void cerrarConexion() {
        try {
            if (ps != null) ps.close();
            if (rs != null) rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            ps = null;
            rs = null;
            CON.desconectar();
        }
    }
}
